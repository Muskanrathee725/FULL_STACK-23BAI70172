import logo from './logo.svg';
import './App.css';

import Counter from './Components/Counter';

function App() {
  return (
    <div>
      <Counter/>
    </div>
  );
}

export default App;
